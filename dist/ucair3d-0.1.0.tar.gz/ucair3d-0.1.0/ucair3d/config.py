import os

ARGS = []
BASE_DIR =  os.path.dirname(os.path.abspath(__file__))
QSS_PATH = os.path.abspath(os.path.join(BASE_DIR, '..', 'ucair3d', 'ui', 'stylesheets'))
ICON_PATH = os.path.abspath(os.path.join(BASE_DIR, '..', 'ucair3d', 'ui', 'icons'))

